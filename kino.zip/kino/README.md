"# kino.ticket" 
